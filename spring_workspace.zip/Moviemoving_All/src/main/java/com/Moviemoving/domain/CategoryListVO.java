package com.Moviemoving.domain;

import lombok.Data;

@Data
public class CategoryListVO {
	private String CategoryList_name;
}
